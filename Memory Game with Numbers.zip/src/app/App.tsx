import { useState, useEffect } from 'react';
import { Brain, RotateCcw, Play, Zap, Trophy, Sparkles, Star } from 'lucide-react';

type GameState = 'start' | 'memorize' | 'input' | 'result';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('start');
  const [numbers, setNumbers] = useState<number[]>([]);
  const [userInput, setUserInput] = useState<string>('');
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [showingNumbers, setShowingNumbers] = useState(true);
  const [timeLeft, setTimeLeft] = useState(0);
  const [streak, setStreak] = useState(0);

  // Progressive difficulty - makin lama makin banyak angka
  const getNumberCount = (level: number) => {
    return Math.min(3 + level - 1, 9); // Mulai dari 3, max 9 angka
  };

  // Waktu makin cepat seiring level naik
  const getTimeForLevel = (level: number) => {
    const baseTime = 5000;
    const reduction = (level - 1) * 200;
    return Math.max(baseTime - reduction, 1000); // Minimum 1 detik
  };

  const generateRandomNumbers = (count: number) => {
    const nums = new Set<number>();
    while (nums.size < count) {
      nums.add(Math.floor(Math.random() * 9) + 1); // Angka 1-9 aja
    }
    return Array.from(nums);
  };

  const startGame = () => {
    const count = getNumberCount(level);
    const time = getTimeForLevel(level);
    const newNumbers = generateRandomNumbers(count);
    setNumbers(newNumbers);
    setSelectedNumbers([]);
    setUserInput('');
    setGameState('memorize');
    setShowingNumbers(true);
    setTimeLeft(time / 1000);

    // Countdown timer
    const countdownInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0.01) {
          clearInterval(countdownInterval);
          return 0;
        }
        return prev - 0.01;
      });
    }, 10);

    // Hide numbers after time
    setTimeout(() => {
      setShowingNumbers(false);
      clearInterval(countdownInterval);
      setTimeout(() => {
        setGameState('input');
      }, 500);
    }, time);
  };

  const handleNumberSelect = (num: number) => {
    if (selectedNumbers.includes(num)) {
      setSelectedNumbers(selectedNumbers.filter(n => n !== num));
    } else {
      if (selectedNumbers.length < getNumberCount(level)) {
        setSelectedNumbers([...selectedNumbers, num]);
      }
    }
  };

  const handleInputNumber = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '') {
      setUserInput('');
      return;
    }
    const num = parseInt(value);
    if (!isNaN(num) && num >= 1 && num <= 99) {
      setUserInput(value);
    }
  };

  const handleAddNumber = () => {
    if (userInput === '') return;
    const num = parseInt(userInput);
    if (!selectedNumbers.includes(num) && selectedNumbers.length < getNumberCount(level)) {
      setSelectedNumbers([...selectedNumbers, num]);
      setUserInput('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddNumber();
    }
  };

  const checkAnswer = () => {
    const correctCount = selectedNumbers.filter(num => numbers.includes(num)).length;
    const wrongCount = selectedNumbers.filter(num => !numbers.includes(num)).length;

    if (correctCount === numbers.length && wrongCount === 0) {
      setScore(score + (level * 10));
      setLevel(level + 1);
      setStreak(streak + 1);
    } else {
      setStreak(0);
    }

    setGameState('result');
  };

  const resetGame = () => {
    setGameState('start');
    setScore(0);
    setLevel(1);
    setNumbers([]);
    setSelectedNumbers([]);
    setStreak(0);
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      {/* Ultra Gen Z Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Neon gradients */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-600/20 via-pink-600/20 to-blue-600/20"></div>
        
        {/* Floating orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full blur-3xl opacity-30 animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gradient-to-r from-pink-400 to-rose-500 rounded-full blur-3xl opacity-30 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-gradient-to-r from-purple-400 to-indigo-500 rounded-full blur-3xl opacity-30 animate-pulse" style={{ animationDelay: '2s' }}></div>
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
      </div>

      <div className="backdrop-blur-2xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 rounded-3xl shadow-2xl p-8 max-w-2xl w-full relative z-10">
        {/* Ultra Modern Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-2xl blur-lg opacity-70 animate-pulse"></div>
              <div className="relative bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 p-3 rounded-2xl">
                <Brain className="w-8 h-8 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-4xl font-black bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent tracking-tight">
                BRAIN BLAST
              </h1>
              <p className="text-white/60 text-sm font-semibold">MEMORY CHALLENGE</p>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2 justify-end mb-1">
              <Star className="w-4 h-4 text-yellow-400 animate-pulse" />
              <span className="text-white/80 text-xs font-bold">LVL {level}</span>
            </div>
            <div className="text-4xl font-black bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
              {score}
            </div>
            {streak > 0 && (
              <div className="text-xs text-cyan-400 font-bold">
                🔥 {streak} STREAK
              </div>
            )}
          </div>
        </div>

        {/* Start Screen */}
        {gameState === 'start' && (
          <div className="text-center py-8">
            <div className="mb-8">
              <div className="text-8xl mb-4 animate-bounce">🧠</div>
              <h2 className="text-5xl font-black bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-3">
                LET'S GOOO!
              </h2>
              <p className="text-white/70 text-lg">Test your memory fr fr 💯</p>
            </div>

            <div className="backdrop-blur-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-white/20 rounded-3xl p-8 mb-8">
              <div className="flex items-center gap-2 justify-center mb-6">
                <Sparkles className="w-6 h-6 text-yellow-400" />
                <h3 className="text-2xl font-black text-white">
                  HOW TO PLAY
                </h3>
                <Sparkles className="w-6 h-6 text-yellow-400" />
              </div>
              
              <div className="space-y-4 text-left max-w-md mx-auto">
                <div className="backdrop-blur-xl bg-white/10 border border-cyan-400/50 rounded-2xl p-5 shadow-lg hover:scale-105 transition-transform">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">👀</span>
                    <span className="text-xl font-black text-cyan-400">WATCH</span>
                  </div>
                  <p className="text-white/80 text-sm">Numbers flash on screen - pay attention!</p>
                </div>
                
                <div className="backdrop-blur-xl bg-white/10 border border-purple-400/50 rounded-2xl p-5 shadow-lg hover:scale-105 transition-transform">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">🧠</span>
                    <span className="text-xl font-black text-purple-400">REMEMBER</span>
                  </div>
                  <p className="text-white/80 text-sm">Memorize all the numbers before they vanish</p>
                </div>
                
                <div className="backdrop-blur-xl bg-white/10 border border-pink-400/50 rounded-2xl p-5 shadow-lg hover:scale-105 transition-transform">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">🎯</span>
                    <span className="text-xl font-black text-pink-400">SELECT</span>
                  </div>
                  <p className="text-white/80 text-sm">Pick all the numbers you remember</p>
                </div>

                <div className="backdrop-blur-xl bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-400/50 rounded-2xl p-5 shadow-lg">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">⚡</span>
                    <span className="text-xl font-black text-yellow-400">LEVEL UP</span>
                  </div>
                  <p className="text-white/80 text-sm font-bold">More numbers + Less time = HARDER! 🔥</p>
                </div>
              </div>
            </div>

            <button
              onClick={startGame}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 rounded-full blur-xl opacity-70 group-hover:opacity-100 transition-opacity animate-pulse"></div>
              <div className="relative bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 text-white px-16 py-6 rounded-full font-black text-2xl hover:scale-110 transition-transform shadow-2xl flex items-center gap-4">
                <Play className="w-8 h-8" />
                START GAME
              </div>
            </button>
          </div>
        )}

        {/* Memorize Screen */}
        {gameState === 'memorize' && (
          <div className="text-center py-8">
            <div className="mb-8">
              {/* Ultra Modern Timer */}
              <div className="relative w-32 h-32 mx-auto mb-6">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full blur-xl opacity-50 animate-pulse"></div>
                <svg className="relative w-32 h-32 transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    className="text-white/10"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="url(#gradient)"
                    strokeWidth="8"
                    fill="none"
                    className="transition-all duration-100"
                    strokeDasharray={`${2 * Math.PI * 56}`}
                    strokeDashoffset={`${2 * Math.PI * 56 * (1 - timeLeft / (getTimeForLevel(level) / 1000))}`}
                    strokeLinecap="round"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#22d3ee" />
                      <stop offset="50%" stopColor="#a855f7" />
                      <stop offset="100%" stopColor="#ec4899" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-black bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
                    {Math.ceil(timeLeft)}
                  </span>
                </div>
              </div>
              
              <div className="text-3xl font-black text-white mb-2 animate-pulse">
                {showingNumbers ? '🔥 MEMORIZE NOW!' : '💭 GET READY...'}
              </div>
              <div className="text-white/60 text-sm font-semibold">
                {getNumberCount(level)} NUMBERS • LEVEL {level}
              </div>
            </div>

            <div className={`grid gap-3 max-w-2xl mx-auto ${
              getNumberCount(level) <= 4 ? 'grid-cols-2' : 
              getNumberCount(level) <= 6 ? 'grid-cols-3' : 'grid-cols-4'
            }`}>
              {showingNumbers ? (
                numbers.map((num, index) => (
                  <div
                    key={index}
                    className="relative group"
                    style={{ 
                      animation: `bounce 0.6s ease-in-out ${index * 0.08}s`,
                      animationFillMode: 'backwards'
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-pink-500 rounded-3xl blur-xl opacity-50 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 text-white text-6xl font-black rounded-3xl aspect-square flex items-center justify-center shadow-2xl border-4 border-white/20">
                      {num}
                    </div>
                  </div>
                ))
              ) : (
                numbers.map((_, index) => (
                  <div
                    key={index}
                    className="bg-white/5 border-2 border-white/20 rounded-3xl aspect-square flex items-center justify-center shadow-lg backdrop-blur-xl"
                  >
                    <span className="text-6xl opacity-30">?</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Input Screen */}
        {gameState === 'input' && (
          <div className="text-center py-8">
            <div className="mb-6">
              <div className="text-3xl font-black text-white mb-3">
                🎯 SELECT THE NUMBERS!
              </div>
              <div className="text-white/60 text-sm font-semibold mb-4">
                Click all {getNumberCount(level)} numbers you remember
              </div>
              <div className="inline-flex items-center gap-3 backdrop-blur-xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-400/50 px-6 py-3 rounded-full">
                <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse shadow-lg shadow-cyan-400/50"></div>
                <span className="font-black text-white text-lg">
                  {selectedNumbers.length} / {getNumberCount(level)}
                </span>
              </div>
            </div>

            {/* Selected Numbers Display */}
            <div className="mb-6 min-h-[80px]">
              <div className="flex flex-wrap gap-2 justify-center max-w-lg mx-auto">
                {selectedNumbers.map((num, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedNumbers(selectedNumbers.filter((_, i) => i !== index))}
                    className="relative group"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-pink-500 rounded-2xl blur-lg opacity-70"></div>
                    <div className="relative bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 text-white text-3xl font-black rounded-2xl px-6 py-3 shadow-xl border-2 border-white/30 hover:scale-110 transition-transform">
                      {num}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Number Grid */}
            <div className="grid grid-cols-3 gap-3 max-w-md mx-auto mb-8">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  onClick={() => handleNumberSelect(num)}
                  disabled={selectedNumbers.includes(num) || selectedNumbers.length >= getNumberCount(level)}
                  className="relative group disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  {selectedNumbers.includes(num) && (
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-pink-500 rounded-2xl blur-xl opacity-70 animate-pulse"></div>
                  )}
                  <div className={`relative text-5xl font-black rounded-2xl aspect-square flex items-center justify-center transition-all shadow-lg ${
                    selectedNumbers.includes(num)
                      ? 'bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 text-white scale-95 border-4 border-white/30'
                      : 'bg-white/10 backdrop-blur-xl text-white/80 hover:bg-white/20 hover:scale-110 border-2 border-white/20'
                  }`}>
                    {num}
                  </div>
                </button>
              ))}
            </div>

            <button
              onClick={checkAnswer}
              disabled={selectedNumbers.length === 0}
              className="relative group disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-pink-500 rounded-full blur-xl opacity-70 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative bg-gradient-to-r from-cyan-400 to-pink-500 text-white px-12 py-5 rounded-full font-black text-xl hover:scale-110 transition-transform shadow-2xl flex items-center gap-3 mx-auto">
                <Sparkles className="w-6 h-6" />
                CHECK ANSWER
              </div>
            </button>
          </div>
        )}

        {/* Result Screen */}
        {gameState === 'result' && (
          <div className="text-center py-8">
            <div className="mb-8">
              {selectedNumbers.filter(num => numbers.includes(num)).length === numbers.length &&
              selectedNumbers.filter(num => !numbers.includes(num)).length === 0 ? (
                <>
                  <div className="text-9xl mb-4 animate-bounce">🔥</div>
                  <h2 className="text-6xl font-black bg-gradient-to-r from-green-400 via-emerald-400 to-cyan-400 bg-clip-text text-transparent mb-3">
                    YASSS!!!
                  </h2>
                  <p className="text-white/70 text-xl font-bold">You're on fire! 💯</p>
                </>
              ) : (
                <>
                  <div className="text-9xl mb-4">😤</div>
                  <h2 className="text-6xl font-black bg-gradient-to-r from-orange-400 via-red-400 to-pink-400 bg-clip-text text-transparent mb-3">
                    SO CLOSE!
                  </h2>
                  <p className="text-white/70 text-xl font-bold">Try again bestie!</p>
                </>
              )}
            </div>

            <div className="backdrop-blur-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-white/20 rounded-3xl p-6 mb-8">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="backdrop-blur-xl bg-green-500/20 border border-green-400/50 rounded-2xl p-6 shadow-lg">
                  <div className="text-xs text-green-300 mb-2 font-bold flex items-center gap-1 justify-center">
                    ✅ CORRECT
                  </div>
                  <div className="text-4xl font-black text-green-400">
                    {numbers.sort((a, b) => a - b).join(' ')}
                  </div>
                </div>
                <div className="backdrop-blur-xl bg-purple-500/20 border border-purple-400/50 rounded-2xl p-6 shadow-lg">
                  <div className="text-xs text-purple-300 mb-2 font-bold flex items-center gap-1 justify-center">
                    📝 YOUR PICK
                  </div>
                  <div className="text-4xl font-black text-purple-400">
                    {selectedNumbers.sort((a, b) => a - b).join(' ') || '-'}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="backdrop-blur-xl bg-green-500/20 border border-green-400/50 rounded-xl p-4 shadow-lg">
                  <div className="text-4xl mb-1">✅</div>
                  <div className="text-3xl font-black text-green-400">
                    {selectedNumbers.filter(num => numbers.includes(num)).length}
                  </div>
                  <div className="text-xs text-green-300 font-bold">RIGHT</div>
                </div>
                <div className="backdrop-blur-xl bg-red-500/20 border border-red-400/50 rounded-xl p-4 shadow-lg">
                  <div className="text-4xl mb-1">❌</div>
                  <div className="text-3xl font-black text-red-400">
                    {selectedNumbers.filter(num => !numbers.includes(num)).length}
                  </div>
                  <div className="text-xs text-red-300 font-bold">WRONG</div>
                </div>
                <div className="backdrop-blur-xl bg-orange-500/20 border border-orange-400/50 rounded-xl p-4 shadow-lg">
                  <div className="text-4xl mb-1">💀</div>
                  <div className="text-3xl font-black text-orange-400">
                    {numbers.filter(num => !selectedNumbers.includes(num)).length}
                  </div>
                  <div className="text-xs text-orange-300 font-bold">MISSED</div>
                </div>
              </div>
            </div>

            <div className="flex gap-4 justify-center flex-wrap">
              <button
                onClick={startGame}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full blur-xl opacity-70 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative bg-gradient-to-r from-cyan-400 to-purple-500 text-white px-10 py-5 rounded-full font-black text-lg hover:scale-110 transition-transform shadow-2xl flex items-center gap-3">
                  <Play className="w-6 h-6" />
                  NEXT LEVEL
                </div>
              </button>
              <button
                onClick={resetGame}
                className="backdrop-blur-xl bg-white/10 border border-white/20 text-white px-10 py-5 rounded-full font-black text-lg hover:scale-110 transition-transform shadow-lg flex items-center gap-3 hover:bg-white/20"
              >
                <RotateCcw className="w-6 h-6" />
                RESTART
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}