
  # Memory Game with Numbers

  This is a code bundle for Memory Game with Numbers. The original project is available at https://www.figma.com/design/wZNuKXRi1Fv1e5WhAc5F28/Memory-Game-with-Numbers.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  